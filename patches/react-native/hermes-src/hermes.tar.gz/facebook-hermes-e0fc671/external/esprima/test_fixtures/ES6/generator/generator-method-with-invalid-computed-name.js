({ *[yield iter]() {} })
