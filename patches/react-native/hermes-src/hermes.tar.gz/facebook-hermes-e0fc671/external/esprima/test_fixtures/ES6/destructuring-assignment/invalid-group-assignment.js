(a,b)=(c,d);
