function *foo() {}
