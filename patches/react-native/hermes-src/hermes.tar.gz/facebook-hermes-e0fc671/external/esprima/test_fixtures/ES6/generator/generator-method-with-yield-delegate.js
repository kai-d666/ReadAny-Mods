({ *foo() { yield* 3; } })
