(function(...x) { "use strict"; })
