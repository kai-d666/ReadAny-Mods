class Foo { static *[foo]() {} }
