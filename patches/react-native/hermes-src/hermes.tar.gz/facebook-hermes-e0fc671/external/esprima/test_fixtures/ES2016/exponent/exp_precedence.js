x * y ** -z
