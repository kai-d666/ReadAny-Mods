class Foo { * }
